structure IntInf = IntInfImp
