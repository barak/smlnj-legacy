structure Substring = InitSubstring
