structure CMB = PPCMacOSCMB
