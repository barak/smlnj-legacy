structure CMB = HppaUnixCMB
