structure CMB = MipsBigUnixCMB
