structure CMB = MipsLittleUnixCMB
