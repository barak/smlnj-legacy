structure MathInlineT = struct end
