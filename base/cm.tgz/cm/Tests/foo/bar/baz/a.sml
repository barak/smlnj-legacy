structure A = struct end
