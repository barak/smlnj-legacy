structure D = struct end
