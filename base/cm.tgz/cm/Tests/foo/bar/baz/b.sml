structure B = A
