structure X = X
