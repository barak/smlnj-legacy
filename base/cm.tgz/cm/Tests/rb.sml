structure S = OS

