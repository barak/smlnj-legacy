structure X = struct end
