structure B = struct end
