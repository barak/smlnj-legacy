structure Y = struct end
