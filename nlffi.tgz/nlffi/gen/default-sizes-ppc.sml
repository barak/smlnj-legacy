structure DefaultSizes = SizesPPC
