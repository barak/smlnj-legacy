structure DefaultSizes = SizesX86
