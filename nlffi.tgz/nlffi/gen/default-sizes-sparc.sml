structure DefaultSizes = SizesSparc

