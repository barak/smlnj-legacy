structure DefaultEndian = EndianLittle
