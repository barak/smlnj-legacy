structure DefaultEndian = EndianBig
