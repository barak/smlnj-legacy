structure MLRiscDefs = MLRiscDefs(MDLAst)
